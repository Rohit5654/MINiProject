﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBank.Entities;
using BloodBank.Exceptions;
using BloodBank.DAL;

namespace BloodBank.BLL
{
    public class BloodBankBLL
    {




        public Hospital Search(int productId)
        {
            try
            {
                ProductDal pd = new ProductDal();
                return pd.Search(productId);
            }
            catch (ProductException)
            {
                throw;
            }
        }


    }
}
