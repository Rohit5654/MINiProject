﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBank.Entities;
using BloodBank.Exceptions;

namespace BloodBank.DAL
{
    public class BloodBankDAL
    {

        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static BloodBankDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public BloodBankDAL()
        {
            con = new SqlConnection(conStr);

        }



        public Hospital Search(int hospitalId)
        {
            Product p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspSearchProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", productId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Product
                    {
                        ProductId = int.Parse(dr["ProductId"].ToString()),
                        ProductName = dr["ProductName"].ToString(),
                        Description = dr["Description"].ToString(),
                        UnitPrice = decimal.Parse(dr["Unitprice"].ToString()),
                        Stock = int.Parse(dr["Stock"].ToString()),
                        Category = int.Parse(dr["Category"].ToString())
                    };
                    dr.Close();
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }
    }
}
