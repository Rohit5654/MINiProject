﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBank.Entities
{
   public  class Hospital
    {
        public int HospitalId { get; set; }
        public int HospitalName { get; set; }
        public int HopsitalAddress{ get; set; }
        public int HospitalCity { get; set; }
        public int ContactNumber { get; set; }
        
    }
}
