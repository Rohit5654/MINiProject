﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BloodBank.BLL;
using BloodBank.Entities;
using BloodBank.Exceptions;



namespace BloodBankUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                BloodBankBLL b1 = new BloodBankBLL();
                Hospital  h = b1.Search(int.Parse(txtHid.Text));
                if ( h!= null)
                {
                    txtHname.Text = h.HospitalName.ToString();
                    txtHadd.Text =h.HopsitalAddress.ToString();
                    txtHcity.Text = h.HospitalCity.ToString();
                    txtHcontact.Text =Convert.ToString(h.ContactNumber);
                    
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Hospital id {0} does not exists.", txtHid.Text),
                        "Blood bank");
                }
            }
            catch (BloodBankException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Blood Bank management System");
            }





        }

        private void txtUP_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
