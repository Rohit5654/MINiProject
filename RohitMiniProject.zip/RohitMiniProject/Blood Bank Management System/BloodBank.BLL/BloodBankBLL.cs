﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBank.Entities;
using BloodBank.Exceptions;
using BloodBank.DAL;

namespace BloodBank.BLL
{
    public class BloodBankBLL
    {




        public Hospital Search(int hospitalId)
        {
            try
            {
                BloodBankDAL pd = new BloodBankDAL();
                return pd.Search(hospitalId);
            }
            catch (BloodBankException )
            {
                throw;
            }
        }

        public bool DeleteHospital(int hospitalId)
        {
            try
            {
                BloodBankDAL pd = new BloodBankDAL();
                return pd.DeleteHospital(hospitalId);
            }
            catch (BloodBankException)
            {
                throw;
            }
        }
        public bool UpdateHospital(Hospital hobj)
        {
            try
            {
                BloodBankDAL pd = new BloodBankDAL();
                return pd.UpdateHospital(hobj);
            }
            catch (BloodBankException)
            {
                throw;
            }
        }


    }
}
