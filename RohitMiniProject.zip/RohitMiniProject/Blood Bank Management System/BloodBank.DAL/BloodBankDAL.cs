﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BloodBank.Entities;
using BloodBank.Exceptions;

namespace BloodBank.DAL
{
    public class BloodBankDAL
    {

        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;



        static BloodBankDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;

        }

        public BloodBankDAL()
        {
            con = new SqlConnection(conStr);

        }



        public Hospital Search(int hospitalId)
        {
            Hospital p = null;

            try
            {
                //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspSearchHospital";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@hId",hospitalId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Hospital
                    {
                        HospitalId=long.Parse(dr["HospitalId"].ToString()),
                        HospitalName = dr["HospitalName"].ToString(),
                        HopsitalAddress = dr["Address"].ToString(),
                        HospitalCity = dr["City"].ToString(),
                        ContactNumber = long.Parse(dr["ContactNumber"].ToString())
                       
                    };
                    dr.Close();
                }
            }
            catch (BloodBankException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }


        public bool DeleteHospital(int hospitalId)
        {
            bool result = false;
            try
            {
                //  con = new SqlConnection();
                // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspDeleteHospital";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@hId", hospitalId);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (BloodBankException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public bool UpdateHospital(Hospital hboj)
        {
            bool result = false;
            try
            {
                // con = new SqlConnection();
                //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "BBank.uspEditHospital";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@hId", hboj.HospitalId);
                cmd.Parameters.AddWithValue("@hName", hboj.HospitalName);
                cmd.Parameters.AddWithValue("@hAdd", hboj.HopsitalAddress);
                cmd.Parameters.AddWithValue("@hCity", hboj.HospitalCity);
                cmd.Parameters.AddWithValue("@hContact", hboj.ContactNumber);
               

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (BloodBankException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }


    }
}
