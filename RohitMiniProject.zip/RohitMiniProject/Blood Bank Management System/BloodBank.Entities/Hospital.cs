﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BloodBank.Entities
{
   public  class Hospital
    {
        public long HospitalId { get; set; }
        public string HospitalName { get; set; }
        public string HopsitalAddress{ get; set; }
        public string HospitalCity { get; set; }
        public long ContactNumber { get; set; }

        
    }
}
