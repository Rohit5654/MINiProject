﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace BloodBank.Exceptions
{
    public class BloodBankException : ApplicationException
    {
        public BloodBankException()
        {
        }

        public BloodBankException(string message) : base(message)
        {
        }

        public BloodBankException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected BloodBankException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
