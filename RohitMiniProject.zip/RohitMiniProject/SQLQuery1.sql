select * from BBank.Hospital

insert into BBank.Hospital values(1234,'trupti','dadr','mumbai',9763885654)



create proc BBank.uspDeleteHospital
(
@hId int
)
as
begin
	delete from BBank.Hospital
	where HospitalId = @hId
end

create proc BBank.uspEditHospital
(
@hId int,
@hName varchar(25),
@hAdd varchar(255),
@hCity varchar(255),
@hContact bigint

)
as
begin
	update BBank.Hospital
	set HospitalName = @hName,[Address]=@hAdd,
	City=@hCity,ContactNumber=@hContact
	where HospitalId = @hId
end